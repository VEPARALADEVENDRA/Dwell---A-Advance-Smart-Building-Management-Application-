package com.example.dwell.User

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.Admin.BillAdapter
import com.example.dwell.R
import com.example.dwell.User.BillData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import okhttp3.internal.notify
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.HashMap
import java.util.Locale

class UserComplaints : AppCompatActivity() {
    private lateinit var back: TextView
    private lateinit var add: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var cmpAdapter: ComplaintAdapter
    private lateinit var owner:String
    private lateinit var buildingcode:String
    private lateinit var block:String
    private lateinit var apart:String
    private lateinit var mykey:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_complaints)

        owner=intent.getStringExtra("phoneNumber").toString()
        buildingcode=intent.getStringExtra("code").toString()
        block=intent.getStringExtra("block").toString()
        apart=intent.getStringExtra("apart").toString()
        mykey=intent.getStringExtra("fcm").toString()

        back = findViewById(R.id.back)
        add = findViewById(R.id.add)
        recyclerview = findViewById(R.id.recyler)
        progress = findViewById(R.id.progressBarComp)

        fetchdata()

        // Initialize billAdapter
        cmpAdapter = ComplaintAdapter(ArrayList())

        // Set billAdapter to RecyclerView
        recyclerview.adapter =cmpAdapter

        back.setOnClickListener {
            finish()
        }

        add.setOnClickListener {
            openDialogData()
        }
    }

    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(owner) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingcode) // Replace with your specific building code
            .child("blocks")
            .child(block)
            .child(apart)
            .child("complaints")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val cmpltList = ArrayList<ComplaintClass>()
                for (billSnapshot in snapshot.children) {
                    val bill = billSnapshot.getValue(ComplaintClass::class.java)
                    bill?.let {
                        cmpltList.add(it)
                    }
                }

                recyclerview.layoutManager = LinearLayoutManager(this@UserComplaints) // Change this line
                cmpAdapter.add(cmpltList) // Change this line
                progress.visibility = View.INVISIBLE

            }

            override fun onCancelled(error: DatabaseError) {
               // Toast.makeText(this@UserComplaints, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }

    override fun onResume() {
        super.onResume()
        fetchdata()
    }

    private fun openDialogData() {

        val dialog = Dialog(this)
        dialog.setContentView(R.layout.user_complaint_admin)
        val complaintTitle = dialog.findViewById<EditText>(R.id.complainthead)
        val complaintDescription = dialog.findViewById<EditText>(R.id.complaintdesc)
        val saveButton = dialog.findViewById<Button>(R.id.save)
        val progressBar = dialog.findViewById<ProgressBar>(R.id.progressBarsendComp)




        saveButton.setOnClickListener {
            val title = complaintTitle.text.toString()
            val descp = complaintDescription.text.toString()
            val sb="sub"+title
            val pr = getCurrentDate()

            if (title.isNotEmpty() && descp.isNotEmpty()  && pr.isNotEmpty() && block.isNotEmpty() && apart.isNotEmpty()) {
                progressBar.visibility = View.VISIBLE

                val database = FirebaseDatabase.getInstance()
                val reference = database.getReference("Users")
                    .child(owner) // Replace with your specific user phone number
                    .child("Buildings")
                    .child(buildingcode) // Replace with your specific building code
                    .child("blocks")
                    .child(block)
                    .child(apart)
                    .child("complaints")
                    .push() // Generate unique key for each bill

                val key=reference.key.toString()

                val comp = ComplaintClass(block,apart,title,sb,descp,pr)

                reference.setValue(comp)
                    .addOnSuccessListener {
                        fetchDataFromRealtimeDatabase()
                        //Toast.makeText(this@UserComplaints, "complaint saved successfully!", Toast.LENGTH_SHORT).show()
                        val database2 = FirebaseDatabase.getInstance()
                        val reference2= database2.getReference("Users")
                            .child(owner) // Replace with your specific user phone number
                            .child("Buildings")
                            .child(buildingcode) // Replace with your specific building code
                            .child("complaints")
                            .child(key)
                        reference2.setValue(comp)
                            .addOnSuccessListener {
                                progressBar.visibility = View.GONE
                                dialog.dismiss()

                            }
                            .addOnFailureListener { e ->
                               // Toast.makeText(this@UserComplaints, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                progressBar.visibility = View.GONE
                            }


                    }
                    .addOnFailureListener { e ->
                       // Toast.makeText(this@UserComplaints, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                        progressBar.visibility = View.GONE
                    }
            } else {
               // Toast.makeText(this@UserComplaints, "Please fill in all fields!", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }


    private fun showDatePickerDialog(deadlineEditText: EditText) {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val selectedDate = Calendar.getInstance()
            selectedDate.set(selectedYear, selectedMonth, selectedDay)

            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val formattedDate = dateFormat.format(selectedDate.time)

            deadlineEditText.setText(formattedDate)
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1 // Months are zero-based in Calendar, so add 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }
    private fun sendRealtimeNotification(mykey: String, donorkey: String) {
        val token: String = mykey

        if (token.isNotEmpty()) {
            val jsonObject = JSONObject()
            val notification = JSONObject()
            notification.put("body", "Hey!! You Have A New Complaint")
            notification.put("title", "Dwell")

            jsonObject.put("to", donorkey)
            jsonObject.put("notification", notification)

            callApi(jsonObject)
        } else {
            showToast("FCM token is empty")
        }
    }
    private fun fetchDataFromRealtimeDatabase() {
        val userReference = FirebaseDatabase.getInstance().getReference("Users").child(owner).child("Buildings").child("ownerFCM")



        userReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                    val key=snapshot.value.toString()


                    sendRealtimeNotification(mykey,key)



                //sendNotification(mutableList)
            }

            override fun onCancelled(error: DatabaseError) {
              //  Toast.makeText(this@UserComplaints,error.message,Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun callApi(jsonObject: JSONObject) {
        val JSON: MediaType = "application/json".toMediaType()
        val client = OkHttpClient()
        val url = "https://fcm.googleapis.com/fcm/send"
        val body = RequestBody.create(JSON, jsonObject.toString())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header(
                "Authorization",
                "Bearer AAAAp_fHqIc:APA91bHxvQvMBi_wRiDQy5wFNTEarvg8Ul_BIcNqoxKDHfrvN1zTmZ1kcyiQ_CdwzXCiqE5fTmii88EpWQu29avoEq72c7axe8n12GlPPQhb0k0E-mKKO0WqhfyXlvNCpV520Zgv2Csh"
            ) // Replace YOUR_SERVER_KEY with your Firebase Cloud Messaging server key
            .build()

        // Show progress bar when starting the network request

        progress.visibility = View.VISIBLE


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Hide progress bar when request completes (either success or failure)

                progress.visibility = View.GONE
                //showToast("Failed to send notification: ${e.message}")

            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    // Hide progress bar when request completes (either success or failure)
                    runOnUiThread {
                        progress.visibility = View.GONE
                       // showToast("Failed to send notification: ${response.code}")
                    }
                } else {
                    // Hide progress bar when request completes successfully
                    runOnUiThread {
                        saveNotificationData()
                        progress.visibility = View.GONE
                        //showToast("Notification Sent Successfully")
                    }
                }
            }

        })
    }

    private fun showToast(message: String) {
        runOnUiThread {
            //Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveNotificationData() {
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(owner)
            .child("Buildings")
            .child(buildingcode)
            .child("Notifications")
            .child("Admin")
            .push()


        progress.visibility = ProgressBar.VISIBLE
        // this is the function to save the notification data

        val interactionData = HashMap<String, Any>()
        interactionData["type"]="complaint"
        interactionData["block"]=block
        interactionData["heading"] = "You have a new Complaint  from  apartment:"+apart+" in block "+block
        interactionData["time"] =getCurrentDate()
        interactionData["date"] = getCurrentTime()

        interactionRef.setValue(interactionData)
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
                NotifyBlink()
               // Toast.makeText(this, "Notification Saved Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Failed  to save  Notification   ", Toast.LENGTH_SHORT).show()
            }
    }
    private fun getCurrentTime(): String {
        val currentTime = Calendar.getInstance()
        val hour = currentTime.get(Calendar.HOUR_OF_DAY)
        val minute = currentTime.get(Calendar.MINUTE)
        val second = currentTime.get(Calendar.SECOND)
        return "$hour:$minute:$second"
    }

    private fun NotifyBlink(){
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(owner)
            .child("Buildings")
            .child(buildingcode)
            .child("Notifications")
            .child("Admin")
            .child("blink").setValue(getCurrentDate()+"/"+getCurrentTime())

        progress.visibility = ProgressBar.VISIBLE


        interactionRef
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
               /// Toast.makeText(this, "Notification Blinked Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Failed  to Blink  Notification   ", Toast.LENGTH_SHORT).show()
            }

    }

}
