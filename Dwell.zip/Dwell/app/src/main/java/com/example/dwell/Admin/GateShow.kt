package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.example.dwell.User.GatePassAdapter
import com.example.dwell.User.GatePassData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class GateShow : AppCompatActivity() {

    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var gateAdapter: Gatepassadapteradm
    private lateinit var mobileuser:String
    private lateinit var Buildingcode:String
    private lateinit var gateprofile:ImageView
    private lateinit var back:ImageView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gate_show)

        recyclerview = findViewById(R.id.recycler)
        progress = findViewById(R.id.progressBar)
        gateprofile=findViewById(R.id.img)

        mobileuser=intent.getStringExtra("mobile").toString()
        Buildingcode=intent.getStringExtra("code").toString()
        back=findViewById(R.id.back)


        back.setOnClickListener {
            finish()
        }



       gateprofile.setOnClickListener {
           openDialogData()
       }

        fetchdata()


        gateAdapter =Gatepassadapteradm(ArrayList())

        // Set billAdapter to RecyclerView
        recyclerview.adapter =gateAdapter
    }

    private fun openDialogData() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.gateprofile)
        val gatekeepernumber= dialog.findViewById<EditText>(R.id.billtitle)
        val gatekeeperpass = dialog.findViewById<EditText>(R.id.billdescription)
        val progressBar = dialog.findViewById<ProgressBar>(R.id.progressBarBill)
        val saveButton=dialog.findViewById<Button>(R.id.save)
        val editButton=dialog.findViewById<Button>(R.id.edit)


        progress.visibility = View.VISIBLE
        val db = FirebaseDatabase.getInstance()
        val ref = db.reference.child("Users")
            .child(mobileuser)
            .child("Buildings")
            .child(Buildingcode)
            .child("GateKeeperCredential")

        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val phoneNumber = snapshot.child("phoneNumber").value.toString()
                    val password = snapshot.child("password").value.toString()
                    gatekeepernumber.setText(phoneNumber)
                    gatekeeperpass.setText(password)
                    editButton.visibility = View.VISIBLE
                    saveButton.visibility = View.INVISIBLE
                    gatekeepernumber.isEnabled=false
                    gatekeeperpass.isEnabled=false
                } else {
                    editButton.visibility = View.INVISIBLE
                    saveButton.visibility = View.VISIBLE
                   // Toast.makeText(this@GateShow, "No gate pass found. Please enter details.", Toast.LENGTH_SHORT).show()
                }
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
               // Toast.makeText(this@GateShow, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.INVISIBLE
            }
        })


        saveButton.setOnClickListener {
           // editButton.visibility=View.VISIBLE
           // saveButton.visibility=View.INVISIBLE
            val title = gatekeepernumber.text.toString()
            val descp = gatekeeperpass.text.toString()


            if (title.isNotEmpty() && descp.isNotEmpty() && gatekeepernumber.text.length==10 && checkInPattern(gatekeepernumber.text.toString()) &&  descp.length<=13 && descp.length>=8 ) {
                progressBar.visibility = View.VISIBLE

                // Saving new bill data to Firebase
                saveGateData(title,descp,editButton,saveButton,progressBar)
            } else {

                if (  descp.length>=13 && descp.length<=8 ){
                    Toast.makeText(this@GateShow, "password must have 8 to 13 characters", Toast.LENGTH_SHORT).show()

                }
                else{
                    Toast.makeText(this@GateShow, "Please  fill valid fields!", Toast.LENGTH_SHORT).show()

                }


            }
        }

        editButton.setOnClickListener {
            gatekeepernumber.isEnabled=true
            gatekeeperpass.isEnabled=true
            saveButton.visibility=View.VISIBLE
            editButton.visibility=View.INVISIBLE
        }

        dialog.show()
    }





    private fun saveGateData(number:String,passw:String,editbutton:Button,saveButton:Button,progressBar: ProgressBar) {
        val phoneNumber = number
        val password = passw

        val db = FirebaseDatabase.getInstance()
        val ref = db.reference.child("Users")
            .child(mobileuser)
            .child("Buildings")
            .child(Buildingcode)
            .child("GateKeeperCredential")

        // Create a HashMap to store phone number and password
        val gatePassData = HashMap<String, Any>()
        gatePassData["phoneNumber"] = phoneNumber
        gatePassData["password"] = password

        // Save the gate pass data to Firebase Database
        ref.setValue(gatePassData)
            .addOnSuccessListener {
                saveGateDataTotal(phoneNumber,password)

                editbutton.visibility=View.VISIBLE
                saveButton.visibility=View.INVISIBLE
                progressBar.visibility=View.INVISIBLE

            }
            .addOnFailureListener {
               // Toast.makeText(this, "Failed to save gate pass: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }



    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.reference.child("Users")
            .child(mobileuser)
            .child("Buildings")
            .child(Buildingcode)
            .child("GatePasses")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val billsList = ArrayList<Gatekepperclassadm>()
                for (billSnapshot in snapshot.children) {
                    val bill = billSnapshot.getValue(Gatekepperclassadm::class.java)
                    bill?.let {

                        billsList.add(bill)
                    }
                }

                recyclerview.layoutManager = LinearLayoutManager(this@GateShow) // Change this line
                gateAdapter.add(billsList) // Change this line
                progress.visibility = View.INVISIBLE

            }

            override fun onCancelled(error: DatabaseError) {
               // Toast.makeText(this@GateShow, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }
    private fun checkInPattern(mobile: String): Boolean {
        // Check if the mobile number consists of the same digit repeated ten times
        val pattern = "^([0-9])\\1{9}\$".toRegex()
        return !pattern.matches(mobile)
    }
    private fun saveGateDataTotal(number:String,passw:String) {
        val phoneNumber =number.trim()
        val password = passw.trim()

        val db = FirebaseDatabase.getInstance()
        val ref = db.reference.child("Users")
            .child("TotalGateKeeperCredentials")
            .child(phoneNumber)

        // Create a HashMap to store phone number and password
        val gatePassData = HashMap<String, Any>()
        gatePassData["owner"]=mobileuser
        gatePassData["buildingcode"]=Buildingcode
        gatePassData["phoneNumber"] = phoneNumber
        gatePassData["password"] = password

        // Save the gate pass data to Firebase Database
        ref.setValue(gatePassData)
            .addOnSuccessListener {
               // Toast.makeText(this, "Gate pass saved successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
               // Toast.makeText(this, "Failed to save gate pass: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }

}