package com.example.dwell

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FCMNotificationService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        remoteMessage.notification?.let {
            // Handle notification message.
            saveNotificationData(it.title ?: "", it.body ?: "")
        }
    }

    private fun saveNotificationData(title: String, message: String) {
        val sharedPreferences: SharedPreferences = applicationContext.getSharedPreferences("NotificationPrefs", Context.MODE_PRIVATE)
        sharedPreferences.edit().putString("NotificationTitle", title).apply()
        sharedPreferences.edit().putString("NotificationMessage", message).apply()
    }

    companion object {
        fun getSavedNotificationTitle(context: Context): String {
            val sharedPreferences: SharedPreferences = context.getSharedPreferences("NotificationPrefs", Context.MODE_PRIVATE)
            return sharedPreferences.getString("NotificationTitle", "") ?: ""
        }

        fun getSavedNotificationMessage(context: Context): String {
            val sharedPreferences: SharedPreferences = context.getSharedPreferences("NotificationPrefs", Context.MODE_PRIVATE)
            return sharedPreferences.getString("NotificationMessage", "") ?: ""
        }
        fun clearNotificationData(context: Context) {
            val sharedPreferences: SharedPreferences = context.getSharedPreferences("NotificationPrefs", Context.MODE_PRIVATE)
            sharedPreferences.edit().remove("NotificationTitle").apply()
            sharedPreferences.edit().remove("NotificationMessage").apply()
        }
    }



    fun showToast(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }
}
