package com.example.dwell.Admin

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.example.dwell.User.UserBillAdapter
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.Calendar

class Interaction : AppCompatActivity() {
    private lateinit var heading: EditText
    private lateinit var subject: EditText
    private lateinit var description: EditText
    private lateinit var save: Button
    private lateinit var progress: ProgressBar
    private lateinit var owner:String
    private lateinit var code:String
    private lateinit var mykey:String

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interaction)

        owner=intent.getStringExtra("mobile").toString()
        code=intent.getStringExtra("code").toString()
        mykey=intent.getStringExtra("fcm").toString()

        heading = findViewById(R.id.complainthead)
        subject = findViewById(R.id.complaintsubj)
        description = findViewById(R.id.complaintdesc)
        save = findViewById(R.id.save)
        progress = findViewById(R.id.progressBarsendComp)

        save.setOnClickListener {
            if (validateFields()) {
                saveDataToDatabase()
            } else {
                //Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateFields(): Boolean {
        val headingText = heading.text.toString().trim()
        val subjectText = subject.text.toString().trim()
        val descriptionText = description.text.toString().trim()

        if (headingText.isEmpty() || subjectText.isEmpty() || descriptionText.isEmpty()) {
            return false
        }

        return true
    }

    private fun saveDataToDatabase() {
        val phoneNumber = owner // Replace with actual implementation
        val headingText = heading.text.toString().trim()
        val subjectText = subject.text.toString().trim()
        val descriptionText = description.text.toString().trim()
        val date = getCurrentDate()

        progress.visibility = ProgressBar.VISIBLE

        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(phoneNumber)
            .child("Buildings")
            .child(code)
            .child("interactions")
            .push()

        val interactionData = HashMap<String, Any>()
        interactionData["heading"] = headingText
        interactionData["subject"] = subjectText
        interactionData["description"] = descriptionText
        interactionData["date"] = date

        interactionRef.setValue(interactionData)
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Interaction saved successfully", Toast.LENGTH_SHORT).show()
                fetchDataFromRealtimeDatabase()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Failed to save interaction", Toast.LENGTH_SHORT).show()
            }
    }

    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1 // Months are zero-based in Calendar, so add 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }
    private fun getCurrentTime(): String {
        val currentTime = Calendar.getInstance()
        val hour = currentTime.get(Calendar.HOUR_OF_DAY)
        val minute = currentTime.get(Calendar.MINUTE)
        val second = currentTime.get(Calendar.SECOND)
        return "$hour:$minute:$second"
    }


    private fun sendRealtimeNotification(mykey: String, donorkey: String) {
        val token: String = mykey

        if (token.isNotEmpty()) {
            val jsonObject = JSONObject()
            val notification = JSONObject()
            notification.put("body", "Hey!! You Have A New Message From Admin")
            notification.put("title", "Dwell")

            jsonObject.put("to", donorkey)
            jsonObject.put("notification", notification)

            callApi(jsonObject)
        } else {
            //showToast("FCM token is empty")
        }
    }
    private fun fetchDataFromRealtimeDatabase() {
        val userReference = FirebaseDatabase.getInstance().getReference("Users").child(owner).child("Buildings").child(code).child("FCMkeys")



        userReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { dataSnapshot ->
                    val number = dataSnapshot.key
                    val key=dataSnapshot.value.toString()
                   // Toast.makeText(this@Interaction,number.toString(),Toast.LENGTH_SHORT).show()

                    sendRealtimeNotification(mykey,key)


                }
                //sendNotification(mutableList)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }


    private fun callApi(jsonObject: JSONObject) {
        val JSON: MediaType = "application/json".toMediaType()
        val client = OkHttpClient()
        val url = "https://fcm.googleapis.com/fcm/send"
        val body = RequestBody.create(JSON, jsonObject.toString())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header(
                "Authorization",
                "Bearer AAAAp_fHqIc:APA91bHxvQvMBi_wRiDQy5wFNTEarvg8Ul_BIcNqoxKDHfrvN1zTmZ1kcyiQ_CdwzXCiqE5fTmii88EpWQu29avoEq72c7axe8n12GlPPQhb0k0E-mKKO0WqhfyXlvNCpV520Zgv2Csh"
            ) // Replace YOUR_SERVER_KEY with your Firebase Cloud Messaging server key
            .build()

        // Show progress bar when starting the network request

        progress.visibility = View.VISIBLE


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Hide progress bar when request completes (either success or failure)

                progress.visibility = View.GONE
               // showToast("Failed to send notification: ${e.message}")

            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    // Hide progress bar when request completes (either success or failure)
                    runOnUiThread {
                        progress.visibility = View.GONE
                        //showToast("Failed to send notification: ${response.code}")
                    }
                } else {
                    // Hide progress bar when request completes successfully
                    runOnUiThread {
                        saveNotificationData()
                        progress.visibility = View.GONE
                      //  showToast("Notification Sent Successfully")
                    }
                }
            }

        })
    }

    private fun saveNotificationData() {
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(owner)
            .child("Buildings")
            .child(code)
            .child("Notifications")
            .child("Users")
            .push()

        val headingText = heading.text.toString().trim()
        val date = getCurrentDate()
        val time=getCurrentTime()

        progress.visibility = ProgressBar.VISIBLE
        // this is the function to save the notification data

        val interactionData = HashMap<String, Any>()
        interactionData["type"]="Interaction"
        interactionData["heading"] = headingText
        interactionData["time"] =time
        interactionData["date"] = date

        interactionRef.setValue(interactionData)
            .addOnSuccessListener {
                NotifyBlink()
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Notification Saved Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Failed  to save  Notification   ", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showToast(message: String) {
        runOnUiThread {
           // Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun NotifyBlink(){
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(owner)
            .child("Buildings")
            .child(code)
            .child("Notifications")
            .child("Users")
            .child("blink").setValue("true")

        progress.visibility = ProgressBar.VISIBLE


        interactionRef
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Notification Blinked Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Failed  to Blink  Notification   ", Toast.LENGTH_SHORT).show()
            }

    }
}
