package com.example.dwell.User

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.dwell.Admin.Directory
import com.example.dwell.FCMNotificationService
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.internal.notify
import java.util.Calendar

class UserMainView : AppCompatActivity() {

    private lateinit var bills:CardView
    private lateinit var directory:CardView
    private  lateinit var interaction:CardView
    private lateinit var complaints:CardView
    private lateinit var gatekeeper:CardView
    private lateinit var userprofile:CardView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var notificationsharedprefernces:SharedPreferences


    private lateinit var billimg:ImageView
    private lateinit var directoryimg:ImageView
    private lateinit var complaintsimg:ImageView
    private lateinit var gatepassimg:ImageView
    private lateinit var interactionimg:ImageView

    private lateinit var mymobile:String
    private lateinit var myname:String
    private lateinit var myapart:String
    private lateinit var myowner:String
    private lateinit var mybuildingcode:String
    private var NOTIFICATION_PERMISSION_REQUEST_CODE = 101
    private lateinit var myblock:String
    private var mainFcm: String = ""
    private lateinit var progress:ProgressBar
    private lateinit var usernametxt:TextView
    private lateinit var storedPassword:String
    private lateinit var notification:RelativeLayout
    private lateinit var dot:CardView
    private lateinit var light:String
    private lateinit var notcheck:String
    private lateinit var mainblinkval:String
    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_main_view)

        sharedPreferences = getSharedPreferences("MyPrefsmainlogin", Context.MODE_PRIVATE)
        notificationsharedprefernces = getSharedPreferences("notifications", Context.MODE_PRIVATE)

        bills=findViewById(R.id.userbills)
        directory=findViewById(R.id.directory)
        interaction=findViewById(R.id.interaction)
        complaints=findViewById(R.id.complaints)
        gatekeeper=findViewById(R.id.gatekepper)
        userprofile=findViewById(R.id.userprofile)
        progress=findViewById(R.id.progressBar)
        usernametxt=findViewById(R.id.username)
        notification=findViewById(R.id.bell)
        dot=findViewById(R.id.dot)


        billimg=findViewById(R.id.imgbill)
        directoryimg=findViewById(R.id.dir)
        complaintsimg=findViewById(R.id.compimg)
        interactionimg=findViewById(R.id.admininteraction)
        gatepassimg=findViewById(R.id.gate)



        myname=sharedPreferences.getString("username", "") ?: ""
        myblock=sharedPreferences.getString("block", "") ?: ""
        myapart=sharedPreferences.getString("apartment", "") ?: ""
        myowner=sharedPreferences.getString("owner", "") ?: ""
        mybuildingcode= sharedPreferences.getString("buildingCode", "") ?: ""
        storedPassword = sharedPreferences.getString("storedPassword", "") ?: ""
        mymobile = sharedPreferences.getString("number", "") ?: ""
        val fcm=sharedPreferences.getString("fcmkey","").toString()

        usernametxt.text=myname+"\uD83D\uDE0A"

        light=notificationsharedprefernces.getString("light","").toString()
        notcheck=notificationsharedprefernces.getString("check","").toString()

        //Toast.makeText(this@UserMainView,notcheck,Toast.LENGTH_SHORT).show()


        if(fcm.isEmpty()){
            getFcmToken()
        }
        else{
            mainFcm=fcm
        }
        checkInternetConnection()
        checkAndRequestNotificationPermission()
        NotifyBlink()
        val notificationTitle = FCMNotificationService.getSavedNotificationTitle(this)

        // Check if there is a notification title
        if (notificationTitle.isNotEmpty()) {
            // Do something with the notification title, such as displaying it
           // Toast.makeText(this, "Notification Title: $notificationTitle", Toast.LENGTH_SHORT).show()


            FCMNotificationService.clearNotificationData(this)
        }




        bills.setOnClickListener {
            val intent=Intent(this,UserBilss::class.java)
            intent.putExtra("phoneNumber",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("block",myblock)
            intent.putExtra("apart",myapart)
            intent.putExtra("fcm",mainFcm)
            startActivity(intent)




        }
        notification.setOnClickListener {
            val intent=Intent(this,UserNotifications::class.java)
            intent.putExtra("phoneNumber",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("block",myblock)
            intent.putExtra("apart",myapart)
            intent.putExtra("fcm",mainFcm)
            intent.putExtra("notcheck",mainblinkval)
            startActivity(intent)
            finish()

        }

        userprofile.setOnClickListener {
            val intent = Intent(this, UserProfile::class.java).apply {
                putExtra("username", myname)
                putExtra("storedPassword", storedPassword)
                putExtra("buildingCode", mybuildingcode)
                putExtra("block", myblock)
                putExtra("apartment", myapart)
                putExtra("owner", myowner)
                putExtra("number",mymobile)
            }
            startActivity(intent)

        }

        directory.setOnClickListener {
            val intent=Intent(this,Directory::class.java)
            intent.putExtra("mobile",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("who","user")
            startActivity(intent)


        }
        interaction.setOnClickListener {
            val intent=Intent(this,UserInteraction::class.java)
            intent.putExtra("phoneNumber",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("block",myblock)
            intent.putExtra("apart",myapart)
            startActivity(intent)


        }
        complaints.setOnClickListener {
            val intent=Intent(this,UserComplaints::class.java)
            intent.putExtra("phoneNumber",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("block",myblock)
            intent.putExtra("apart",myapart)
            intent.putExtra("username",myname)
            intent.putExtra("fcm",mainFcm)
            startActivity(intent)

        }
        gatekeeper.setOnClickListener {
            val intent=Intent(this,UserGatePass::class.java)
            intent.putExtra("phoneNumber",myowner)
            intent.putExtra("code",mybuildingcode)
            intent.putExtra("block",myblock)
            intent.putExtra("apart",myapart)
            intent.putExtra("username",myname)
            startActivity(intent)

        }



    }
    private fun NotifyBlink() {
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(myowner)
            .child("Buildings")
            .child(mybuildingcode)
            .child("Notifications")
            .child("Users")
            .child("blink")

        progress.visibility = ProgressBar.VISIBLE

        interactionRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                progress.visibility = ProgressBar.GONE

                val blinkValue = dataSnapshot.getValue(String::class.java)
                mainblinkval=blinkValue.toString()
                //Toast.makeText(this@UserMainView,blinkValue+"=="+notcheck,Toast.LENGTH_SHORT).show()
                if(blinkValue.toString().isEmpty() || notcheck.isEmpty() ){
                    dot.visibility=View.INVISIBLE

                }
                else  if (blinkValue!=notcheck) {
                    dot.visibility=View.VISIBLE

                }
                else {
                    dot.visibility=View.INVISIBLE
                }


            }

            override fun onCancelled(databaseError: DatabaseError) {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this@UserMainView, "Failed to fetch blink status", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun getFcmToken() {
        progress.visibility=View.VISIBLE
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token: String? = task.result
                token?.let {
                    mainFcm = it
                    saveFCMKEYToFireBase()
                }
            } else {
                // Handle error
               // Toast.makeText(this,"Error Making Key", Toast.LENGTH_SHORT).show()
                progress.visibility=View.INVISIBLE
            }
        }
    }

    private fun saveFCMKEYToFireBase() {

        val userReference = FirebaseDatabase.getInstance().getReference("Users").child(myowner).child("Buildings").child(mybuildingcode).child("FCMkeys").child(mymobile)
        userReference.setValue(mainFcm)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    saveFCMKEYToFireBase2()
                } else {
                    progress.visibility=View.INVISIBLE
                    //Toast.makeText(this, "Failed to save data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
    private fun saveFCMKEYToFireBase2() {

        val userReference = FirebaseDatabase.getInstance().getReference("Users").child(myowner).child("Buildings").child(mybuildingcode).child("BillFCM").child(myblock).child(mymobile)
        userReference.setValue(mainFcm)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val editor = sharedPreferences.edit()
                    editor.putString("fcmkey",mainFcm)
                    editor.apply()
                    progress.visibility=View.INVISIBLE
                   // Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show()
                } else {
                    progress.visibility=View.INVISIBLE
                  //  Toast.makeText(this, "Failed to save data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        } else {
            //
        }
    }
    private fun checkAndRequestNotificationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.POST_NOTIFICATIONS)) {
                showExplanationDialog()
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST_CODE)
            }
        }
    }

    private fun showExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Notification Permission Needed")
            .setMessage("This app needs permission to send you notifications about important updates and features. Granting this permission will allow you to receive timely information directly within the app.")
            .setPositiveButton("OK") { _, _ ->
                // Prompt the user once explanation has been shown
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST_CODE)
            }
            .create()
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                // Permission was granted
                // You can now send notifications
            } else {
                // Permission denied
                // Disable the functionality that depends on this permission.
            }
        }
    }
    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }

    override fun onResume() {
        super.onResume()
        NotifyBlink()
    }
}