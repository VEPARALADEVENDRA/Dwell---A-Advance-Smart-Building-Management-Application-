package com.example.dwell.Admin

data class BlockDetailsModel(
    val blockname: String? = null,
    val totalfloors: String? = null,
    val maxunits: String? = null,
    val selected: String? = null // Storing ID of selected format ImageView

)
