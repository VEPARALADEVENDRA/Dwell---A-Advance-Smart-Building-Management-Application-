package com.example.dwell.Admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.User.BillData
import com.example.dwell.R
import com.example.dwell.User.InteractionData

class InteractionAdapter(private var billList: List<InteractionData>) : RecyclerView.Adapter<InteractionAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val interactionTitle: TextView = itemView.findViewById(R.id.messagetitle)
        private val interactionSub:TextView=itemView.findViewById(R.id.intxt)
        private val intearctionDescription:TextView=itemView.findViewById(R.id.outxt)
        private val dd:TextView=itemView.findViewById(R.id.dd)

        fun bind(bill: InteractionData) {
            interactionTitle.text=bill.heading
            interactionSub.text=bill.subject
            intearctionDescription.text=bill.description
            dd.text=bill.date

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.interaction_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(billList[position])
    }

    override fun getItemCount(): Int {
        return billList.size
    }

    fun add(bills: List<InteractionData>) {
        billList = bills
        notifyDataSetChanged()
    }
}
