package com.example.dwell.User

data class NotificationClass(
    val date: String = "",
    val heading: String = "",
    val time: String = "",
    val type: String = "",
    val block:String=""
)