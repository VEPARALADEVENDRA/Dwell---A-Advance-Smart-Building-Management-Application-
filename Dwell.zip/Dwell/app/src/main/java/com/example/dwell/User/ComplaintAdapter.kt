package com.example.dwell.User


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.User.BillData
import com.example.dwell.R

class ComplaintAdapter(private var cmpList: List<ComplaintClass>) : RecyclerView.Adapter<ComplaintAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {



        private val blocknum:TextView=itemView.findViewById(R.id.Blocknumber)
        private val flatnum:TextView=itemView.findViewById(R.id.flatnumber)
        private val complaintheading:TextView=itemView.findViewById(R.id.complainheading)
        private val  complaintSub:TextView=itemView.findViewById(R.id.complaintsub)
        private val compdate:TextView=itemView.findViewById(R.id.date)

        fun bind(comp: ComplaintClass) {
            blocknum.text = comp.blocknumber
            flatnum.text = comp.apartnumber
            complaintheading.text = comp.complaintheading
            complaintSub.text = comp.complaintDescription
            compdate.text=comp.complaintdate
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.complaint_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(cmpList[position])
    }

    override fun getItemCount(): Int {
        return cmpList.size
    }

    fun add(compls: List<ComplaintClass>) {
        cmpList = compls
        notifyDataSetChanged()
    }
}
