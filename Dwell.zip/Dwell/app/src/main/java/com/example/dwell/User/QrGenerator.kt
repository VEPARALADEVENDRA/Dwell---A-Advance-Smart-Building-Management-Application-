package com.example.dwell.User

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import com.example.dwell.R
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.journeyapps.barcodescanner.BarcodeEncoder
import kotlin.random.Random

class QrGenerator : AppCompatActivity() {

    private lateinit var qrCodeImageView: ImageView
    private lateinit var qrUniqueCode: TextView
    private lateinit var share: Button
    private lateinit var uniqCode: String
    private lateinit var name: String
    private lateinit var phoneNumber: String
    private lateinit var address: String
    private lateinit var fromDate: String
    private lateinit var toDate: String
    private lateinit var block: String
    private lateinit var apart: String
    private lateinit var ownerName: String

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_generator)

        // Receive intent strings
        uniqCode = intent.getStringExtra("uniq").toString()
        name = intent.getStringExtra("Name").toString()
        phoneNumber = intent.getStringExtra("PhoneNumber").toString()
        address = intent.getStringExtra("Address").toString()
        fromDate = intent.getStringExtra("FromDate").toString()
        toDate = intent.getStringExtra("ToDate").toString()
        block = intent.getStringExtra("Block").toString()
        apart = intent.getStringExtra("Flat").toString()
        ownerName = intent.getStringExtra("OwnerName").toString()

        qrCodeImageView = findViewById(R.id.qrCodeImageView)
        qrUniqueCode = findViewById(R.id.QrTextView)
        share = findViewById(R.id.share)

        // Set text for unique code
        qrUniqueCode.text = uniqCode

        // Generate QR code
        generateQRCode()

        // Share QR code onClick
        share.setOnClickListener {
            shareCodeQr()
        }
    }

    private fun generateQRCode() {
        try {
            // Generate QR code
            val multiFormatWriter = MultiFormatWriter()
            val bitMatrix = multiFormatWriter.encode(uniqCode, BarcodeFormat.QR_CODE, 500, 500)
            val barcodeEncoder = BarcodeEncoder()
            val bitmap: Bitmap = barcodeEncoder.createBitmap(bitMatrix)
            qrCodeImageView.setImageBitmap(bitmap)
        } catch (e: WriterException) {
            e.printStackTrace()
        }
    }

    private fun shareCodeQr() {
        // Get URI of the generated QR code image
        val uri: Uri = getImageUri(this, qrCodeImageView)

        // Create intent to share the QR code image along with the details
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.putExtra(
            Intent.EXTRA_TEXT,
            "Name: $name\nPhone Number: $phoneNumber\nAddress: $address\nFrom Date: $fromDate\nTo Date: $toDate\nBlock: $block\nFlat: $apart\nOwner Name: $ownerName\nUnique Code: $uniqCode"
        )

        // Start sharing intent
        startActivity(Intent.createChooser(intent, "Share QR Code and Details via"))
    }

    private fun getImageUri(inContext: AppCompatActivity, inImage: ImageView): Uri {
        val bitmap = (inImage.drawable).toBitmap()
        val path = MediaStore.Images.Media.insertImage(
            inContext.contentResolver,
            bitmap,
            "QRCode",
            null
        )
        return Uri.parse(path)
    }
}
