package com.example.dwell.Admin


import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.AdminprofileClass
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.random.Random

class AddBuilding : AppCompatActivity() {

    private lateinit var next: Button
    private lateinit var mobile: String
    private lateinit var BuildingCode: String
    private lateinit var mobilenumber: EditText
    private lateinit var editTextName: EditText
    private lateinit var editTextState: EditText
    private lateinit var editTextPincode: EditText
    private lateinit var editTextCity: EditText
    private lateinit var editTextAddress: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var phnum:String
    private lateinit var bc:String
    private lateinit var editing:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_building)

        next = findViewById(R.id.buttonNext)
        mobilenumber = findViewById(R.id.editTextMobile)
        editTextName = findViewById(R.id.editTextName)
        editTextState = findViewById(R.id.editTextState)
        editTextPincode = findViewById(R.id.editTextPincode)
        editTextCity = findViewById(R.id.editTextCity)
        editTextAddress = findViewById(R.id.editTextAddress)
        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = ProgressBar.GONE // Initially hide progress bar

        sharedPreferences = getSharedPreferences("MyPrefsbuilding", Context.MODE_PRIVATE)
        phnum = sharedPreferences.getString("phoneNumber", "").toString()
        bc=sharedPreferences.getString("BuildingCode","").toString()
        editing=intent.getStringExtra("edit").toString()
        if(editing=="edit"){
            mobile=phnum
            BuildingCode=phnum
            mobilenumber.setText(mobile)
            fetchData()


        }


        else if (phnum.isNotEmpty() && bc.isNotEmpty()) {
            val intent = Intent(this, BuildingDetails::class.java) // Replace YourActivity with your desired activity
            intent.putExtra("phoneNumber",phnum)
            intent.putExtra("code", bc)
            startActivity(intent)
            finish()
        }
        //fetchData()
        else{
            mobile = intent.getStringExtra("phoneNumber").toString()
            mobilenumber.setText(mobile)


            BuildingCode = mobile
            //Toast.makeText(this, BuildingCode, Toast.LENGTH_SHORT).show()

            fetchData()

        }



        next.setOnClickListener {
            if (checkFieldsNotEmpty()) {
                progressBar.visibility = ProgressBar.VISIBLE
                addDataToFirebase()
            } else {
                //Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkFieldsNotEmpty(): Boolean {
        return editTextName.text.isNotEmpty() &&
                editTextState.text.isNotEmpty() &&
                editTextPincode.text.isNotEmpty() &&
                editTextCity.text.isNotEmpty() &&
                editTextAddress.text.isNotEmpty()
    }

    private fun addDataToFirebase() {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile)

        val adminProfile = hashMapOf(
            "name" to editTextName.text.toString(),
            "state" to editTextState.text.toString(),
            "pincode" to editTextPincode.text.toString(),
            "city" to editTextCity.text.toString(),
            "address" to editTextAddress.text.toString(),
            "phone" to mobile
        )

        reference.child("adminprofile").setValue(adminProfile)
            .addOnSuccessListener {
                val editor = sharedPreferences.edit()
                editor.putString("phoneNumber", mobile)
                editor.putString("BuildingCode",BuildingCode)
                editor.apply()

                progressBar.visibility = ProgressBar.GONE
                val intent = Intent(this, BuildingDetails::class.java)
                intent.putExtra("mobile", mobile)
                intent.putExtra("code", BuildingCode)
                intent.putExtra("edit",editing)
                startActivity(intent)

                finish()
            }
            .addOnFailureListener {
                progressBar.visibility = ProgressBar.GONE
                showErrorDialog(it.message ?: "Unknown error occurred")
            }
    }
    private fun BuildingData() {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile)

        val adminProfile = hashMapOf(
            "name" to editTextName.text.toString(),
            "state" to editTextState.text.toString(),
            "pincode" to editTextPincode.text.toString(),
            "city" to editTextCity.text.toString(),
            "address" to editTextAddress.text.toString(),
            "phone" to mobile
        )

        reference.child("adminprofile").setValue(adminProfile)
            .addOnSuccessListener {
                val editor = sharedPreferences.edit()
                editor.putString("phoneNumber", mobile)
                editor.putString("BuildingCode",BuildingCode)
                editor.apply()

                progressBar.visibility = ProgressBar.GONE
                val intent = Intent(this, BuildingDetails::class.java)
                intent.putExtra("mobile", mobile)
                intent.putExtra("code", BuildingCode)
                startActivity(intent)

                finish()
            }
            .addOnFailureListener {
                progressBar.visibility = ProgressBar.GONE
                showErrorDialog(it.message ?: "Unknown error occurred")
            }
    }

    private fun generateRandomBuildingCode(): String {
        val letters = ('A'..'Z').toList()
        val digits = ('0'..'9').toList()
        val random = Random.Default

        val codeBuilder = StringBuilder()

        repeat(5) {
            codeBuilder.append(letters.random(random))
            codeBuilder.append(digits.random(random))
        }

        return codeBuilder.toString()
    }

    private fun showErrorDialog(errorMessage: String) {
        AlertDialog.Builder(this)
            .setMessage(errorMessage)
            .setPositiveButton("OK", DialogInterface.OnClickListener { dialog, _ ->
                dialog.dismiss()
            })
            .create()
            .show()
    }
    private fun fetchData() {
        val databaseReference: DatabaseReference = FirebaseDatabase.getInstance().getReference("Users").child(mobile).child("adminprofile")
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val adminProfile = dataSnapshot.getValue(AdminprofileClass::class.java)
                    adminProfile?.let {
                        editTextName.setText(it.name)
                        editTextState.setText(it.state)
                        editTextPincode.setText(it.pincode)
                        editTextCity.setText(it.city)
                        editTextAddress.setText(it.address)
                    }

                    progressBar.visibility= View.INVISIBLE
                } else {
                    // Show dialog if no data is available
                    progressBar.visibility= View.INVISIBLE

                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Show error dialog
                showErrorDialog(databaseError.message)
            }
        })
    }
}
