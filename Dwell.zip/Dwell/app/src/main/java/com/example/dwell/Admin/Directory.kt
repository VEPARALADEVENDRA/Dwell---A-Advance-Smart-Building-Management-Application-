package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.R
import com.google.firebase.database.*

class Directory : AppCompatActivity() {

    private lateinit var plumberName: EditText
    private lateinit var plumberPhoneNumber: EditText
    private lateinit var electricianName: EditText
    private lateinit var electricianPhoneNumber: EditText
    private lateinit var carpenterName: EditText
    private lateinit var carpenterPhoneNumber: EditText
    private lateinit var cleanerName: EditText
    private lateinit var cleanerPhoneNumber: EditText
    private lateinit var painterName: EditText
    private lateinit var painterPhoneNumber: EditText
    private lateinit var saveButton: Button
    private lateinit var editButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var databaseReference: DatabaseReference
    private lateinit var mobile: String
    private lateinit var BuildingCode: String
    private lateinit var who:String
    private lateinit var back:TextView
    private lateinit var others1passion:EditText
    private lateinit var others1name:EditText
    private lateinit var others1number:EditText


    private lateinit var others2passion:EditText
    private lateinit var others2name:EditText
    private lateinit var others2number:EditText



    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_directory)

        mobile=intent.getStringExtra("mobile").toString()
        //Toast.makeText(this@Directory,mobile,Toast.LENGTH_SHORT).show()

        BuildingCode=intent.getStringExtra("code").toString()
        //Toast.makeText(this@Directory,BuildingCode,Toast.LENGTH_SHORT).show()
        who=intent.getStringExtra("who").toString()

        // Initialize views
        plumberName = findViewById(R.id.namePlumber)
        plumberPhoneNumber = findViewById(R.id.phoneNumberPlumber)
        electricianName = findViewById(R.id.nameElectrician)
        electricianPhoneNumber = findViewById(R.id.phoneNumberElectrician)
        carpenterName = findViewById(R.id.nameCarpenter)
        carpenterPhoneNumber = findViewById(R.id.phoneNumberCarpenter)
        cleanerName = findViewById(R.id.nameCleaner)
        cleanerPhoneNumber = findViewById(R.id.phoneNumberCleaner)
        painterName = findViewById(R.id.namePainter)
        painterPhoneNumber = findViewById(R.id.phoneNumberPainter)
        saveButton = findViewById(R.id.save)
        editButton = findViewById(R.id.edit)
        progressBar = findViewById(R.id.progressBar)
        back=findViewById(R.id.back)


        others1passion=findViewById(R.id.ot1name)
        others1name=findViewById(R.id.ot1edit)
        others1number=findViewById(R.id.ot1editnumber)


        others2passion=findViewById(R.id.ot2name)
        others2name=findViewById(R.id.ot2edit)
        others2number=findViewById(R.id.ot2editnumber)

        if (who=="user"){
            saveButton.visibility=View.INVISIBLE
            editButton.visibility=View.INVISIBLE
        }



        // Get Firebase reference
        val database = FirebaseDatabase.getInstance()
        databaseReference = database.getReference("Users").child(mobile).child("Buildings").child(BuildingCode).child("directory")

        // Set onClickListener for save button
        saveButton.setOnClickListener {
            // Check if all fields are filled
            if (validateFields() && validateFields2()) {
                saveButton.visibility=View.INVISIBLE
                editButton.visibility=View.VISIBLE
                // Save data to Firebase
                saveDataToFirebase()
            } else {
                // Display error dialog
                showErrorDialog()
            }
        }
        back.setOnClickListener {
            finish()
        }

        // Set onClickListener for edit button
        editButton.setOnClickListener {
            enableEditMode()
        }

        // Check for existing data
        checkForData()
    }

    private fun checkForDataInShared(){

    }

    private fun checkForData() {
        progressBar.visibility = View.VISIBLE
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    plumberName.setText(snapshot.child("plumber").child("name").value.toString())
                    plumberPhoneNumber.setText(snapshot.child("plumber").child("phoneNumber").value.toString())
                    electricianName.setText(snapshot.child("electrician").child("name").value.toString())
                    electricianPhoneNumber.setText(snapshot.child("electrician").child("phoneNumber").value.toString())
                    carpenterName.setText(snapshot.child("carpenter").child("name").value.toString())
                    carpenterPhoneNumber.setText(snapshot.child("carpenter").child("phoneNumber").value.toString())
                    cleanerName.setText(snapshot.child("cleaner").child("name").value.toString())
                    cleanerPhoneNumber.setText(snapshot.child("cleaner").child("phoneNumber").value.toString())
                    painterName.setText(snapshot.child("painter").child("name").value.toString())
                    painterPhoneNumber.setText(snapshot.child("painter").child("phoneNumber").value.toString())


                    others1passion.setText(snapshot.child("others1").child("role").value.toString())
                    others1name.setText(snapshot.child("others1").child("name").value.toString())
                    others1number.setText(snapshot.child("others1").child("phoneNumber").value.toString())

                    others2passion.setText(snapshot.child("others2").child("role").value.toString())
                    others2name.setText(snapshot.child("others2").child("name").value.toString())
                    others2number.setText(snapshot.child("others2").child("phoneNumber").value.toString())

                    // Disable EditText fields
                    disableEditTexts()

                    // Enable edit button
                    if (who=="user"){
                        editButton.visibility = View.INVISIBLE
                        saveButton.visibility=View.INVISIBLE

                    }
                    else{
                        editButton.visibility = View.VISIBLE
                        saveButton.visibility=View.INVISIBLE

                    }

                }
                progressBar.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.INVISIBLE
               // showToast("Failed to retrieve data: ${error.message}")
            }
        })
    }

    private fun enableEditMode() {
        // Enable EditText fields
        enableEditTexts()

        // Disable edit button
        editButton.visibility = View.INVISIBLE
        saveButton.visibility=View.VISIBLE

        // Request focus for plumber name EditText
        plumberName.requestFocus()
    }

    private fun disableEditTexts() {
        plumberName.isEnabled = false
        plumberPhoneNumber.isEnabled = false
        electricianName.isEnabled = false
        electricianPhoneNumber.isEnabled = false
        carpenterName.isEnabled = false
        carpenterPhoneNumber.isEnabled = false
        cleanerName.isEnabled = false
        cleanerPhoneNumber.isEnabled = false
        painterName.isEnabled = false
        painterPhoneNumber.isEnabled = false
    }

    private fun enableEditTexts() {
        plumberName.isEnabled = true
        plumberPhoneNumber.isEnabled = true
        electricianName.isEnabled = true
        electricianPhoneNumber.isEnabled = true
        carpenterName.isEnabled = true
        carpenterPhoneNumber.isEnabled = true
        cleanerName.isEnabled = true
        cleanerPhoneNumber.isEnabled = true
        painterName.isEnabled = true
        painterPhoneNumber.isEnabled = true
    }

    private fun validateFields(): Boolean {
        // Check if all EditText fields are not empty
        return (plumberName.text.isNotBlank() && plumberPhoneNumber.text.isNotBlank()
                && electricianName.text.isNotBlank() && electricianPhoneNumber.text.isNotBlank()
                && carpenterName.text.isNotBlank() && carpenterPhoneNumber.text.isNotBlank()
                && cleanerName.text.isNotBlank() && cleanerPhoneNumber.text.isNotBlank()
                && painterName.text.isNotBlank() && painterPhoneNumber.text.isNotBlank())
    }

    private fun saveDataToFirebase() {
        // Show progress bar
        progressBar.visibility = View.VISIBLE

        // Save data to Firebase
        databaseReference.child("plumber").child("name").setValue(plumberName.text.toString())
        databaseReference.child("plumber").child("phoneNumber").setValue(plumberPhoneNumber.text.toString())
        databaseReference.child("electrician").child("name").setValue(electricianName.text.toString())
        databaseReference.child("electrician").child("phoneNumber").setValue(electricianPhoneNumber.text.toString())
        databaseReference.child("carpenter").child("name").setValue(carpenterName.text.toString())
        databaseReference.child("carpenter").child("phoneNumber").setValue(carpenterPhoneNumber.text.toString())
        databaseReference.child("cleaner").child("name").setValue(cleanerName.text.toString())
        databaseReference.child("cleaner").child("phoneNumber").setValue(cleanerPhoneNumber.text.toString())
        databaseReference.child("painter").child("name").setValue(painterName.text.toString())
        databaseReference.child("painter").child("phoneNumber").setValue(painterPhoneNumber.text.toString())
        databaseReference.child("others1").child("role").setValue(others1passion.text.toString())
        databaseReference.child("others1").child("name").setValue(others1name.text.toString())
        databaseReference.child("others1").child("phoneNumber").setValue(others1number.text.toString())
        databaseReference.child("others2").child("role").setValue(others2passion.text.toString())
        databaseReference.child("others2").child("name").setValue(others2name.text.toString())
        databaseReference.child("others2").child("phoneNumber").setValue(others2number.text.toString())

            .addOnSuccessListener {
                // Data saved successfully
                //showToast("Data saved successfully!")
                // Hide progress bar after data is saved
                progressBar.visibility = View.INVISIBLE
                finish()
            }
            .addOnFailureListener { e ->
                // Data failed to save
               // showToast("Failed to save data: ${e.message}")
                // Hide progress bar after data is saved
                progressBar.visibility = View.INVISIBLE
            }
    }

    private fun showToast(message: String) {
        //Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showErrorDialog() {
        // Display error dialog if any field is empty
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Please fill in all fields correctly.")
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }

    private fun saveSharedPreferences() {
        val editor = sharedPreferences.edit()

        editor.putString("plumberName", plumberName.text.toString())
        editor.putString("plumberPhoneNumber", plumberPhoneNumber.text.toString())
        editor.putString("electricianName", electricianName.text.toString())
        editor.putString("electricianPhoneNumber", electricianPhoneNumber.text.toString())
        editor.putString("carpenterName", carpenterName.text.toString())
        editor.putString("carpenterPhoneNumber", carpenterPhoneNumber.text.toString())
        editor.putString("cleanerName", cleanerName.text.toString())
        editor.putString("cleanerPhoneNumber", cleanerPhoneNumber.text.toString())
        editor.putString("painterName", painterName.text.toString())
        editor.putString("painterPhoneNumber", painterPhoneNumber.text.toString())

        editor.apply()
    }

    private fun validateFields2(): Boolean {
        // Check if all EditText fields are not empty and contain valid data
        return (isNameValid(plumberName.text.toString()) && isNameValid(electricianName.text.toString())
                && isNameValid(carpenterName.text.toString()) && isNameValid(cleanerName.text.toString())
                && isNameValid(painterName.text.toString()) && isNameValid(others1name.text.toString()) && isNameValid(others2name.text.toString()) && isNameValid(others1passion.text.toString()) && isNameValid(others2passion.text.toString()))
    }

    private fun isNameValid(name: String): Boolean {
        // Regular expression to allow only alphabetic characters and spaces
        val regex = "^[a-zA-Z ]+\$".toRegex()
        return regex.matches(name)
    }


}
