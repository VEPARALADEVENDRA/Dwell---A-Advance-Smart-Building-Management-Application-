package com.example.dwell.Admin

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class BuildingDetails : AppCompatActivity() {

    private lateinit var next: Button
    private lateinit var buildingName: EditText
    private lateinit var numberOfBlocks: EditText
    private lateinit var editTextState: EditText
    private lateinit var editTextPincode: EditText
    private lateinit var editTextCity: EditText
    private lateinit var editTextAddress: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var mobile: String
    private lateinit var buildingCode: String
    private lateinit var sharedPreferences2: SharedPreferences
    private lateinit var editing:String
    private lateinit var mainphn:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_building_details)

        next = findViewById(R.id.buttonNext2)
        buildingName = findViewById(R.id.editTextName)
        numberOfBlocks = findViewById(R.id.numberoffloors)
        editTextState = findViewById(R.id.editTextState)
        editTextPincode = findViewById(R.id.editTextPincode)
        editTextCity = findViewById(R.id.editTextCity)
        editTextAddress = findViewById(R.id.editTextAddress)
        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = ProgressBar.GONE // Initially hide progress bar

        editing=intent.getStringExtra("edit").toString()

        sharedPreferences2 = getSharedPreferences("MyPrefsdetails", Context.MODE_PRIVATE)
        val phnum = sharedPreferences2.getString("phoneNumber", "").toString()
        mainphn=phnum
        val bc = sharedPreferences2.getString("BuildingCode", "").toString()
        val tb = sharedPreferences2.getString("totalblocks", "").toString()
        val buildingname = sharedPreferences2.getString("buildname", "").toString()


        mobile = intent.getStringExtra("mobile").toString()
        buildingCode = intent.getStringExtra("code").toString()

        if (editing=="edit" ){
            fetchBuildingData(mobile,bc)

        } else if (phnum.isNotEmpty() && bc.isNotEmpty() && tb.isNotEmpty() && buildingname.isNotEmpty() && editing!="edit") {
            val intent = Intent(this, BlockViews::class.java)
            intent.putExtra("mobile", phnum)
            intent.putExtra("code", bc)
            intent.putExtra("totalblocks", tb)
            intent.putExtra("buildname", buildingname)
            startActivity(intent)
            finish()

        } else {


            fetchBuildingData(mobile,mobile)
        }

        next.setOnClickListener {
            if (checkFieldsNotEmpty()) {
                progressBar.visibility = ProgressBar.VISIBLE
                addDataToFirebase()
            } else {
                //Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun checkFieldsNotEmpty(): Boolean {
        return buildingName.text.isNotEmpty() &&
                numberOfBlocks.text.isNotEmpty() &&
                editTextState.text.isNotEmpty() &&
                editTextPincode.text.isNotEmpty() &&
                editTextCity.text.isNotEmpty() &&
                editTextAddress.text.isNotEmpty()
    }

    private fun addDataToFirebase() {


        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile).child("Buildings").child(buildingCode)

        val buildingProfile = hashMapOf(
            "buildingName" to buildingName.text.toString(),
            "numberOfBlocks" to numberOfBlocks.text.toString(),
            "state" to editTextState.text.toString(),
            "pincode" to editTextPincode.text.toString(),
            "city" to editTextCity.text.toString(),
            "address" to editTextAddress.text.toString()
        )

        reference.child("buildingprofile").setValue(buildingProfile)
            .addOnSuccessListener {
                progressBar.visibility = ProgressBar.GONE
                showSuccessDialog()

                val intent = Intent(this, BlockViews::class.java)
                intent.putExtra("mobile", mobile)
                intent.putExtra("code", buildingCode)
                intent.putExtra("totalblocks", numberOfBlocks.text.toString())
                intent.putExtra("buildname", buildingName.text.toString())
                intent.putExtra("str","me")
                intent.putExtra("edit","edit")
                //Toast.makeText(this,"buildingname"+buildingName.text.toString(),Toast.LENGTH_SHORT).show()

                // Store the building name in SharedPreferences
                val editor = sharedPreferences2.edit()
                editor.putString("phoneNumber", mobile)
                editor.putString("BuildingCode", buildingCode)
                editor.putString("totalblocks", numberOfBlocks.text.toString())
                editor.putString("buildname", buildingName.text.toString())
                editor.apply()

                startActivity(intent)
                //AddBuildingData()
            }
            .addOnFailureListener {
                progressBar.visibility = ProgressBar.GONE
                showErrorDialog(it.message ?: "Unknown error occurred")
            }
    }
    private fun AddBuildingData() {

        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile).child("Buildings")



        reference.child("buildingprofile").child(buildingName.text.toString()).setValue(mobile)
            .addOnSuccessListener {
                progressBar.visibility = ProgressBar.GONE
                showSuccessDialog()

                val intent = Intent(this, BlockViews::class.java)
                intent.putExtra("mobile", mobile)
                intent.putExtra("code", buildingCode)
                intent.putExtra("totalblocks", numberOfBlocks.text.toString())
                intent.putExtra("buildname", buildingName.text.toString())
                intent.putExtra("str","me")
                intent.putExtra("edit","edit")
               // Toast.makeText(this,"buildingname"+buildingName.text.toString(),Toast.LENGTH_SHORT).show()

                // Store the building name in SharedPreferences
                val editor = sharedPreferences2.edit()
                editor.putString("phoneNumber", mobile)
                editor.putString("BuildingCode", buildingCode)
                editor.putString("totalblocks", numberOfBlocks.text.toString())
                editor.putString("buildname", buildingName.text.toString())
                editor.apply()

                startActivity(intent)
            }
            .addOnFailureListener {
                progressBar.visibility = ProgressBar.GONE
               // showErrorDialog(it.message ?: "Unknown error occurred")
            }
    }

    private fun showSuccessDialog() {
        AlertDialog.Builder(this)
            .setMessage("Building data added successfully!")
            .setPositiveButton("OK", DialogInterface.OnClickListener { dialog, _ ->
                dialog.dismiss()
            })
            .create()
            .show()
    }

    private fun showErrorDialog(errorMessage: String) {
        AlertDialog.Builder(this)
            .setMessage(errorMessage)
            .setPositiveButton("OK", DialogInterface.OnClickListener { dialog, _ ->
                dialog.dismiss()
            })
            .create()
            .show()
    }
    private fun fetchBuildingData(phno:String,bc:String) {
       
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(phno).child("Buildings").child(bc).child("buildingprofile")

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val buildingProfile = dataSnapshot.value as? Map<String, String>
                    buildingProfile?.let {
                        // Set data to EditText fields
                        buildingName.setText(it["buildingName"])
                        numberOfBlocks.setText(it["numberOfBlocks"])
                        editTextState.setText(it["state"])
                        editTextPincode.setText(it["pincode"])
                        editTextCity.setText(it["city"])
                        editTextAddress.setText(it["address"])
                    }
                } else {
                   // Toast.makeText(this@BuildingDetails,"Data Doesnt Exist",Toast.LENGTH_SHORT).show()
                    // Data doesn't exist, you can handle this case if needed
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
               // showErrorDialog(databaseError.message ?: "Unknown error occurred")
            }
        })
    }


}
