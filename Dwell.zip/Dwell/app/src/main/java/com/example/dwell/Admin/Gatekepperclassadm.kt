package com.example.dwell.Admin

class Gatekepperclassadm (
    val Name: String="",
    val PhoneNumber: String="",
    val Address: String="",
    val FromDate: String="",
    val ToDate: String="",
    val Block: String="",
    val Flat: String="",
    val OwnerName: String="",
    val uniqcode:String=""

)