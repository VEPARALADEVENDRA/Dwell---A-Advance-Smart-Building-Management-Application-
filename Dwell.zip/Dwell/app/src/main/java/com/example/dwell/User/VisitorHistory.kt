package com.example.dwell.User

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dwell.R

class VisitorHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visitor_history)
    }
}