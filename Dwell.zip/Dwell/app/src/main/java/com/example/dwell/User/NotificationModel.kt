package com.example.dwell.User

data class NotificationModel(
    val type: String? = null,
    val block: String? = null,
    val heading: String? = null,
    val time: String? = null,
    val date: String? = null
)
