package com.example.dwell.Admin

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.example.dwell.User.ComplaintAdapter
import com.example.dwell.User.ComplaintClass
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Complaints : AppCompatActivity() {
    private lateinit var back: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var cmpAdapter: ComplaintAdapter
    private lateinit var mobile:String
    private lateinit var Buildingcode:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_complaints)

        mobile=intent.getStringExtra("mobile").toString()
        Buildingcode=intent.getStringExtra("code").toString()

        back = findViewById(R.id.back)
        recyclerview = findViewById(R.id.recycler)
        progress = findViewById(R.id.progressBar)

        fetchdata()

        // Initialize billAdapter
        cmpAdapter = ComplaintAdapter(ArrayList())

        // Set billAdapter to RecyclerView
        recyclerview.adapter =cmpAdapter

        back.setOnClickListener {
            finish()
        }

    }
    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(mobile) // Replace with your specific user phone number
            .child("Buildings")
            .child(Buildingcode) // Replace with your specific building code
            .child("complaints")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val cmpltList = ArrayList<ComplaintClass>()
                for (billSnapshot in snapshot.children) {
                    val bill = billSnapshot.getValue(ComplaintClass::class.java)
                    bill?.let {
                        cmpltList.add(it)
                    }
                }

                recyclerview.layoutManager = LinearLayoutManager(this@Complaints) // Change this line
                cmpAdapter.add(cmpltList) // Change this line
                progress.visibility = View.INVISIBLE

            }

            override fun onCancelled(error: DatabaseError) {
                //Toast.makeText(this@Complaints, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }
}