package com.example.dwell

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.database.FirebaseDatabase
import java.util.concurrent.TimeUnit

class RegisterActivity : AppCompatActivity() {

    private lateinit var mobileNumber:EditText
    private lateinit var enterOTP:EditText
    private lateinit var sendOtp:Button
    private lateinit var VerifyOtp:Button
    private lateinit var progress:ProgressBar
    private lateinit var verificationcode:String
    private var timeoutseconds:Long=60L
    private  lateinit var resendingtoken: PhoneAuthProvider.ForceResendingToken
    private lateinit var password:EditText
    private lateinit var save:Button

    private val mAuth: FirebaseAuth = FirebaseAuth.getInstance()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        sendOtp=findViewById(R.id.sendotpbutton_signupactivity)
        mobileNumber=findViewById(R.id.mobilenumber_registrationactivity)
        enterOTP=findViewById(R.id.enterotp_registeractivity)
        VerifyOtp=findViewById(R.id.verifyotpbutton_signupactivity)
        progress=findViewById(R.id.progressBar)
        password=findViewById(R.id.enterpass_registeractivity)
        save=findViewById(R.id.savebutton_signupactivity)

        enterOTP.visibility = View.INVISIBLE
        VerifyOtp.visibility = View.INVISIBLE
        password.visibility = View.INVISIBLE
        save.visibility = View.INVISIBLE

        sendOtp.setOnClickListener {
            if(mobileNumber.text.toString().isNotEmpty() && mobileNumber.text.toString().length==10  && checkInPattern(mobileNumber.text.toString())){
                val number="+91"+mobileNumber.text.toString()
                sendotp(number,false)
            }
            else{
               Toast.makeText(this,"Enter Valid Mobile Number",Toast.LENGTH_SHORT).show()
            }
        }

        VerifyOtp.setOnClickListener {
            val otp = enterOTP.text.toString()
            if (otp.isNotEmpty()) {
                verifyotp(otp)
            } else {
              //  Toast.makeText(this, "Please enter the OTP", Toast.LENGTH_SHORT).show()
            }
        }
        save.setOnClickListener {
            saveDataToFireBase()
        }
    }

    private fun saveDataToFireBase() {
        val phoneNumber = mobileNumber.text.toString()
        val pass = password.text.toString()


        if(phoneNumber.isNotEmpty() && pass.isNotEmpty() && pass.length>=8 && pass.length<=13  && checkInPattern(phoneNumber)){
            val userReference = FirebaseDatabase.getInstance().getReference("Users").child("Authentication").child(phoneNumber)
            setInProgress(true)
            userReference.setValue(pass)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                       // Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show()
                        // Navigate to the main activity after successful registration
                        val intent = Intent(this, MainActivity::class.java)
                        intent.putExtra("Phonenumber",phoneNumber)
                        startActivity(intent)
                        finish()
                    } else {
                       //Toast.makeText(this, "Failed to save data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                    setInProgress(false)
                }

        }
        else{
            if (pass.length<=8 && pass.length>=13){
                Toast.makeText(this, "enter valid password (password must contain between 8 and 13 characters)", Toast.LENGTH_SHORT).show()

            }
            else{
                Toast.makeText(this, "enter valid credentials", Toast.LENGTH_SHORT).show()
            }


        }


    }
    private fun checkInPattern(mobile: String): Boolean {
        // Check if the mobile number consists of the same digit repeated ten times
        val pattern = "^([0-9])\\1{9}\$".toRegex()
        return !pattern.matches(mobile)
    }

    private fun verifyotp(otp: String) {
        val credential = PhoneAuthProvider.getCredential(verificationcode, otp)
        signInWithPhoneAuthCredential(credential)
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        mAuth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val user = task.result?.user
                   // Toast.makeText(applicationContext, "Authentication successful", Toast.LENGTH_LONG).show()
                    password.visibility=View.VISIBLE
                    enterOTP.visibility=View.INVISIBLE
                    VerifyOtp.visibility=View.INVISIBLE
                    save.visibility=View.VISIBLE

                } else {
                    // Sign in failed, display a message to the user.
                   // Toast.makeText(applicationContext, "Authentication failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    fun sendotp(phonenumber:String, isresend:Boolean){
        setInProgress(true)
        val options = PhoneAuthOptions.newBuilder(mAuth)
            .setPhoneNumber(phonenumber) // Phone number to verify
            .setTimeout(timeoutseconds, TimeUnit.SECONDS) // Timeout and unit
            .setActivity(this) // Activity (for callback binding)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    setInProgress(false)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                  Toast.makeText(applicationContext, "Verification Failed: ${e.message}", Toast.LENGTH_LONG).show()
                    setInProgress(false)
                }

                override fun onCodeSent(p0: String, p1: PhoneAuthProvider.ForceResendingToken) {
                    super.onCodeSent(p0, p1)
                    verificationcode=p0
                    resendingtoken=p1
                    Toast.makeText(applicationContext, "otp sent successfully", Toast.LENGTH_LONG).show()
                    mobileNumber.isEnabled=false
                    sendOtp.visibility=View.INVISIBLE
                    enterOTP.visibility=View.VISIBLE
                    VerifyOtp.visibility=View.VISIBLE
                    setInProgress(false)
                }
            })

        if (isresend) {
            options.setForceResendingToken(resendingtoken)
        }

        PhoneAuthProvider.verifyPhoneNumber(options.build())
    }

    fun setInProgress(inProgress:Boolean){
        if(inProgress){
            progress.visibility = View.VISIBLE
        }
        else{
            progress.visibility = View.GONE
        }
    }
}
