package com.example.dwell.Admin
import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.User.BillData
import com.example.dwell.R
import com.google.firebase.database.*

class BillAdapter(private var billList: List<BillData>) : RecyclerView.Adapter<BillAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private val billTitle: TextView = itemView.findViewById(R.id.billheading)
        private val billDescription: TextView = itemView.findViewById(R.id.billdescription)
        private val deadline: TextView = itemView.findViewById(R.id.deadline)
        private val price: TextView = itemView.findViewById(R.id.pricett)
        private val block: TextView = itemView.findViewById(R.id.block)

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(bill: BillData) {
            billTitle.text = bill.title
            billDescription.text = bill.description
            deadline.text = bill.deadline
            price.text = "₹" + bill.price
            block.text = bill.block
        }

        override fun onClick(view: View?) {
            val clickedBill = billList[adapterPosition]

            // Build dialog box with "Paid" and "Unpaid" buttons
            val dialogBuilder = AlertDialog.Builder(itemView.context)
            dialogBuilder.setTitle("Select Status")
            dialogBuilder.setPositiveButton("Paid") { dialog, which ->
                showPaidApartments(clickedBill)
            }
            dialogBuilder.setNegativeButton("Unpaid") { dialog, which ->
                showunPaidApartments(clickedBill)
            }
            dialogBuilder.show()
        }
        private fun showunPaidApartments(bill: BillData) {
            val database = FirebaseDatabase.getInstance()
            val reference = database.getReference("Users")
                .child(bill.owner)
                .child("Buildings")
                .child(bill.buildingcode)
                .child("Bills")
                .child(bill.block)
                .child(bill.key)
                .child("pending")

            reference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val paidApartments = ArrayList<String>()
                    for (apartmentSnapshot in dataSnapshot.children) {
                        val apartmentName = apartmentSnapshot.key
                        apartmentName?.let { paidApartments.add(it) }
                    }
                    showUnPaidApartmentsDialog(paidApartments)
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle errors
                }
            })
        }

        private fun showPaidApartments(bill: BillData) {
            val database = FirebaseDatabase.getInstance()
            val reference = database.getReference("Users")
                .child(bill.owner)
                .child("Buildings")
                .child(bill.buildingcode)
                .child("Bills")
                .child(bill.block)
                .child(bill.key)
                .child("paid")

            reference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val paidApartments = ArrayList<String>()
                    for (apartmentSnapshot in dataSnapshot.children) {
                        val apartmentName = apartmentSnapshot.key
                        apartmentName?.let { paidApartments.add(it) }
                    }
                    showPaidApartmentsDialog(paidApartments)
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle errors
                }
            })
        }

        private fun showPaidApartmentsDialog(paidApartments: ArrayList<String>) {
            val dialogBuilder = AlertDialog.Builder(itemView.context)
            dialogBuilder.setTitle("Paid Apartments")
            dialogBuilder.setItems(paidApartments.toTypedArray()) { dialog, which ->
                // Handle item click if needed
            }
            dialogBuilder.show()
        }
        private fun showUnPaidApartmentsDialog(paidApartments: ArrayList<String>) {
            val dialogBuilder = AlertDialog.Builder(itemView.context)
            dialogBuilder.setTitle("UnPaid Apartments")
            dialogBuilder.setItems(paidApartments.toTypedArray()) { dialog, which ->
                // Handle item click if needed
            }
            dialogBuilder.show()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.bill_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(billList[position])
    }

    override fun getItemCount(): Int {
        return billList.size
    }

    fun add(bills: List<BillData>) {
        billList = bills
        notifyDataSetChanged()
    }
}
