package com.example.dwell.User

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar

class GatePassAdapter(private var GateList: List<GatePassData>) : RecyclerView.Adapter<GatePassAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val visitorName: TextView = itemView.findViewById(R.id.name)
        private val visitorInDate: TextView = itemView.findViewById(R.id.indate)
        private val visitorOutDate: TextView = itemView.findViewById(R.id.outdate)


        fun bind(Gate: GatePassData) {
            visitorName.text = Gate.Name
            visitorInDate.text=Gate.FromDate
           visitorOutDate.text = Gate.ToDate

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.user_profile_item, parent, false)
        val viewHolder = ViewHolder(view)
        view.setOnClickListener {
            val position = viewHolder.adapterPosition

            if (position != RecyclerView.NO_POSITION) {
                // Get the bill at the clicked position
                val bill = GateList[position]

                // Open dialog with custom layout
                showDialog(view.context, bill)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(GateList[position])
    }

    override fun getItemCount(): Int {
        return GateList.size
    }

    fun add(bills: List<GatePassData>) {
        GateList = bills
        notifyDataSetChanged()
    }

    @SuppressLint("MissingInflatedId")
    private fun showDialog(context: Context, gate: GatePassData) {
        // Inflate your custom dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.visitorprofile, null)

        val builder = AlertDialog.Builder(context)
        builder.setView(dialogView)
        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()

        val progress = dialogView.findViewById<ProgressBar>(R.id.progressBar)
        val back=dialogView.findViewById<TextView>(R.id.back)

        back.setOnClickListener {
            dialog.dismiss()
        }



        // Customize your dialog view (e.g., set bill details)
        val visitorName=dialogView.findViewById<EditText>(R.id.username)
        visitorName.setText(gate.Name)
        visitorName.isEnabled=false
        val visitorPhone=dialogView.findViewById<EditText>(R.id.phonetxt)
        visitorPhone.setText(gate.PhoneNumber)
        visitorPhone.isEnabled=false
        val visitorAddress=dialogView.findViewById<EditText>(R.id.usermail)
        visitorAddress.setText(gate.Address)
        visitorAddress.isEnabled=false
        val visitorFlat=dialogView.findViewById<EditText>(R.id.flatnumber)
        visitorFlat.setText(gate.Flat)
       visitorFlat.isEnabled=false
        val visitorBlock=dialogView.findViewById<EditText>(R.id.userblock)
        visitorBlock.setText(gate.Block)
        visitorBlock.isEnabled=false
        val visitorOwnerName=dialogView.findViewById<EditText>(R.id.ownername)
        visitorOwnerName.setText(gate.OwnerName)
        visitorOwnerName.isEnabled=false
        val fromDate=dialogView.findViewById<EditText>(R.id.usercardnumber)
        fromDate.setText(gate.FromDate)
       fromDate.isEnabled=false
        val toDate=dialogView.findViewById<EditText>(R.id.todatetxt)
        toDate.setText(gate.ToDate)
        toDate.isEnabled=false

        val uniqcodetxt=dialogView.findViewById<EditText>(R.id.uniquecode)
        uniqcodetxt.setText(gate.uniqcode)
        uniqcodetxt.isEnabled=false
        /*val uniq=dialog.findViewById<EditText>(R.id.code)
        uniq.setText(gate.uniqcode)*/


        progress.visibility = View.INVISIBLE

        val displayMetrics = context.resources.displayMetrics
        val dialogWidth = (displayMetrics.widthPixels * 0.9).toInt() // 90% of screen width
        val dialogHeight = (displayMetrics.heightPixels * 0.9).toInt() // 90% of screen height
        dialogView.layoutParams = ViewGroup.LayoutParams(dialogWidth, dialogHeight)

        // Create and show the dialog
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }
        dialog.show()
    }

    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1 // Months are zero-based in Calendar, so add 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }

}
