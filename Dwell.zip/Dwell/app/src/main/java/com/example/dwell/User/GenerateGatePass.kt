package com.example.dwell.User

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.dwell.R
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class GenerateGatePass : AppCompatActivity() {

    private lateinit var saveButton: Button
    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var fromDateEditText: TextView
    private lateinit var toDateEditText: TextView
    private lateinit var uniqcode: String
    private lateinit var progress: ProgressBar
    private lateinit var owner: String
    private lateinit var buildingcode: String
    private lateinit var block: String
    private lateinit var apart: String
    private lateinit var username: String
    private var fromDate: Calendar? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_gate_pass)

        saveButton = findViewById(R.id.okbutton)
        nameEditText = findViewById(R.id.username)
        phoneEditText = findViewById(R.id.phonetxt)
        addressEditText = findViewById(R.id.usermail)
        fromDateEditText = findViewById(R.id.usercardnumber)
        toDateEditText = findViewById(R.id.todatetxt)
        progress = findViewById(R.id.progressBar)

        owner = intent.getStringExtra("phoneNumber").toString()
        buildingcode = intent.getStringExtra("code").toString()
        block = intent.getStringExtra("block").toString()
        apart = intent.getStringExtra("apart").toString()
        username = intent.getStringExtra("username").toString()

        toDateEditText.isEnabled = false // Disable toDateEditText initially

        fromDateEditText.setOnClickListener {
            showFromDatePickerDialog()
        }
        toDateEditText.setOnClickListener {
            showToDatePickerDialog()
        }

        uniqcode = getUniqueCode()

        saveButton.setOnClickListener {
            if (validateFields()) {
                // Proceed with further action
                saveDataToRealtimeDatabase(uniqcode)
            } else {
                showToast("Fill all details or valid details")
            }
        }
    }

    private fun showFromDatePickerDialog() {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                fromDate = Calendar.getInstance().apply {
                    set(selectedYear, selectedMonth, selectedDay)
                }
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val formattedDate = dateFormat.format(fromDate!!.time)
                fromDateEditText.text = formattedDate
                toDateEditText.isEnabled = true // Enable toDateEditText after selecting fromDate
            },
            year,
            month,
            day
        )

        datePickerDialog.datePicker.minDate = currentDate.timeInMillis
        datePickerDialog.show()
        setDatePickerButtonColors(datePickerDialog)
    }

    private fun showToDatePickerDialog() {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = Calendar.getInstance().apply {
                    set(selectedYear, selectedMonth, selectedDay)
                }
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val formattedDate = dateFormat.format(selectedDate.time)
                toDateEditText.text = formattedDate
            },
            year,
            month,
            day
        )

        fromDate?.let {
            datePickerDialog.datePicker.minDate = it.timeInMillis
        } ?: run {
            datePickerDialog.datePicker.minDate = currentDate.timeInMillis
        }

        datePickerDialog.show()
        setDatePickerButtonColors(datePickerDialog)
    }

    private fun setDatePickerButtonColors(datePickerDialog: DatePickerDialog) {
        val positiveButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_POSITIVE)
        positiveButton.setTextColor(ContextCompat.getColor(this, R.color.black))
        val negativeButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_NEGATIVE)
        negativeButton.setTextColor(ContextCompat.getColor(this, R.color.black))
    }

    private fun saveDataToRealtimeDatabase(uniqueCode: String) {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val usersRef = database.reference.child("Users")
            .child(owner)
            .child("Buildings").child(buildingcode)
            .child("GatePasses")
            .child(uniqueCode)

        val name = nameEditText.text.toString()
        val phoneNumber = phoneEditText.text.toString()
        val address = addressEditText.text.toString()
        val fromDate = fromDateEditText.text.toString()
        val toDate = toDateEditText.text.toString()

        val gatePassData = HashMap<String, String>().apply {
            put("Name", name)
            put("PhoneNumber", phoneNumber)
            put("Address", address)
            put("FromDate", fromDate)
            put("ToDate", toDate)
            put("Block", block)
            put("Flat", apart)
            put("OwnerName", username)
            put("uniqcode", uniqcode)
        }

        usersRef.setValue(gatePassData)
            .addOnSuccessListener {
                //showToast("Data saved successfully!")
                addUnderHim(uniqueCode)
            }
            .addOnFailureListener {
                progress.visibility = View.INVISIBLE
                // showToast("Failed to save data.")
            }
    }

    private fun addUnderHim(uniqueCode: String) {
        val database2 = FirebaseDatabase.getInstance()
        val usersRef2 = database2.reference.child("Users")
            .child(owner)
            .child("Buildings")
            .child(buildingcode)
            .child("blocks")
            .child(block)
            .child(apart)
            .child("GatePasses")
            .child(uniqueCode)

        val name = nameEditText.text.toString()
        val phoneNumber = phoneEditText.text.toString()
        val address = addressEditText.text.toString()
        val fromDate = fromDateEditText.text.toString()
        val toDate = toDateEditText.text.toString()

        val gatePassData = HashMap<String, String>().apply {
            put("Name", name)
            put("PhoneNumber", phoneNumber)
            put("Address", address)
            put("FromDate", fromDate)
            put("ToDate", toDate)
            put("Block", block)
            put("Flat", apart)
            put("OwnerName", username)
            put("uniqcode", uniqcode)
        }

        usersRef2.setValue(gatePassData)
            .addOnSuccessListener {
                // showToast("Data saved successfully!")
                progress.visibility = View.INVISIBLE
                val intent = Intent(this, QrGenerator::class.java)
                intent.putExtra("uniq", uniqueCode)

                intent.putExtra("Name",name)
                intent.putExtra("PhoneNumber", phoneNumber)
                intent.putExtra("Address", address)
                intent.putExtra("FromDate", fromDate)
                intent.putExtra("ToDate", toDate)
                intent.putExtra("Block", block)
                intent.putExtra("Flat", apart)
                intent.putExtra("OwnerName", username)
                intent.putExtra("uniqcode", uniqcode)

                startActivity(intent)
                finish()
            }
            .addOnFailureListener {
                progress.visibility = View.INVISIBLE
                // showToast("Failed to save data.")
            }
    }

    private fun validateFields(): Boolean {
        return !(nameEditText.text.toString().isEmpty() ||
                phoneEditText.text.toString().isEmpty() ||
                addressEditText.text.toString().isEmpty() ||
                fromDateEditText.text.toString().isEmpty() ||
                toDateEditText.text.toString().isEmpty() ||
                phoneEditText.text.toString().length != 10 ||!checkInPattern(phoneEditText.text.toString()))
    }
    private fun checkInPattern(mobile: String): Boolean {
        // Check if the mobile number consists of the same digit repeated ten times
        val pattern = "^([0-9])\\1{9}\$".toRegex()
        return !pattern.matches(mobile)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun getUniqueCode(): String {
        val characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return (0 until 8)
            .map { characters[Random.nextInt(characters.length)] }
            .joinToString("")
    }
}
