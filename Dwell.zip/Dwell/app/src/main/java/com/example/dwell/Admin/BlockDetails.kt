package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class BlockDetails : AppCompatActivity() {

    private lateinit var blockname: EditText
    private lateinit var totalFloors: EditText
    private lateinit var maxunits: EditText
    private lateinit var next: Button

    private lateinit var form1: RelativeLayout
    private lateinit var form2: RelativeLayout


    private lateinit var mobile: String
    private lateinit var buildingcode: String
    private lateinit var blockButtonName: String

    private lateinit var selected:String
    private lateinit var totalblocks:String

    private var selectedFormat: RelativeLayout? = null

    private lateinit var progress:ProgressBar

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block_details)

        blockButtonName = intent.getStringExtra("buttonText").toString()

        mobile = intent.getStringExtra("mobile").toString()
        buildingcode = intent.getStringExtra("code").toString()
        totalblocks=intent.getStringExtra("total").toString()

        blockname = findViewById(R.id.blockname)
        totalFloors = findViewById(R.id.totalfloors)
        maxunits = findViewById(R.id.maxunits)

        progress=findViewById(R.id.progressBar)




        next = findViewById(R.id.nextbutton)

      /*  form1.setOnClickListener {
            selected="1"
            form1.setBackgroundColor(ContextCompat.getColor(this, R.color.pastel_red))
            form2.setBackgroundColor(ContextCompat.getColor(this, R.color.white))


        }
        form2.setOnClickListener {
            selected="2"
            form1.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
            form2.setBackgroundColor(ContextCompat.getColor(this, R.color.pastel_red))


        }*/

        next.setOnClickListener {
            if (checkFieldsNotEmpty() ) {

                saveDataToFirebase()

            } else {
               // Toast.makeText(this, "Please fill in all details", Toast.LENGTH_SHORT).show()
            }
        }
        checkBlockDataInFirebase()
    }

    private fun saveDataToFirebase() {
        progress.visibility=View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile).child("Buildings").child(buildingcode)
            .child("blocks").child(blockButtonName).child("Details")

        val blockDetails = HashMap<String, Any>()
        blockDetails["blockname"] = blockname.text.toString()
        blockDetails["totalfloors"] = totalFloors.text.toString()
        blockDetails["maxunits"] = maxunits.text.toString()
        //blockDetails["selected"]=selected
        //blockDetails["selectedFormat"] = getSelectedFormatIndex() // Storing index of selected format RelativeLayout

        reference.setValue(blockDetails)
            .addOnSuccessListener {
               // Toast.makeText(this, "Details saved successfully", Toast.LENGTH_SHORT).show()
                progress.visibility=View.INVISIBLE
                navigate()
            }
            .addOnFailureListener { e ->
              //  Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                progress.visibility=View.INVISIBLE
            }
    }



    private fun checkFieldsNotEmpty(): Boolean {
        return blockname.text.isNotEmpty() &&
                totalFloors.text.isNotEmpty() &&
                maxunits.text.isNotEmpty()
    }

    private fun checkBlockDataInFirebase() {
        progress.visibility=View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile).child("Buildings").child(buildingcode)
            .child("blocks").child(blockButtonName).child("Details")

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val blockDetails = snapshot.getValue(BlockDetailsModel::class.java)
                    blockname.setText(blockDetails?.blockname)
                    totalFloors.setText(blockDetails?.totalfloors)
                    maxunits.setText(blockDetails?.maxunits)
                    val sel=blockDetails?.selected


                    progress.visibility = View.INVISIBLE
                } else {
                    progress.visibility = View.INVISIBLE
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility = View.INVISIBLE
                //Toast.makeText(this@BlockDetails, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }




    private fun navigate() {
        val intent = Intent(this, EachSectionInBlock::class.java)
        intent.putExtra("mobile", mobile)
        intent.putExtra("blockbutton", blockButtonName)
        intent.putExtra("code", buildingcode)
        intent.putExtra("total",totalblocks)
        intent.putExtra("blockname", blockname.text.toString())
        intent.putExtra("totalfloors", totalFloors.text.toString())
        intent.putExtra("maxunits", maxunits.text.toString())
        startActivity(intent)
        finish()
    }
}
