package com.example.dwell.User

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.Admin.InteractionAdapter
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UserInteraction : AppCompatActivity() {
    private lateinit var back: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var interactionAdapter: InteractionAdapter
    private lateinit var owner: String
    private lateinit var buildingcode: String
    private lateinit var block: String
    private lateinit var apart: String

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_interaction)

        back = findViewById(R.id.back)
        recyclerview = findViewById(R.id.recycler)
        progress = findViewById(R.id.progressBar)

        owner = intent.getStringExtra("phoneNumber").toString()
        buildingcode = intent.getStringExtra("code").toString()
        block = intent.getStringExtra("block").toString()
        apart = intent.getStringExtra("apart").toString()

        fetchdata()

        // Initialize billAdapter
        interactionAdapter = InteractionAdapter(ArrayList())

        // Set billAdapter to RecyclerView
        recyclerview.adapter = interactionAdapter

        back.setOnClickListener {
            finish()
        }


    }

    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(owner)
            .child("Buildings")
            .child(buildingcode)
            .child("interactions")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val billsList = ArrayList<InteractionData>()
                for (billSnapshot in snapshot.children) {
                    val key = billSnapshot.key // Get the bill key
                    val bill = billSnapshot.getValue(InteractionData::class.java)
                    bill?.let {
                        billsList.add(bill)
                    }
                }

                if (billsList.isEmpty()) {
                    // Display a message indicating no interactions available
                    showDialogNoInteractions()
                    // or showToastNoInteractions()
                } else {
                    recyclerview.layoutManager = LinearLayoutManager(this@UserInteraction)
                    interactionAdapter.add(billsList)
                }
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
             //   Toast.makeText(this@UserInteraction, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()progress.visibility = View.GONE
            }
        })
    }

    private fun showDialogNoInteractions() {
        // Create a dialog to inform the user that there are no interactions available
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setMessage("No interactions available.")
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        val alert = dialogBuilder.create()
        alert.show()
    }

    private fun showToastNoInteractions() {
        // Show a toast message to inform the user that there are no interactions available
      //  Toast.makeText(this, "No interactions available.", Toast.LENGTH_SHORT).show()
    }
}