package com.example.dwell.Admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.Dialog
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.example.dwell.User.BillData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class Bills : AppCompatActivity() {
    private lateinit var back: TextView
    private lateinit var add: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var billAdapter: BillAdapter
    private lateinit var mobile:String
    private lateinit var buildingCode:String
    private lateinit var mykey: String
    private lateinit var block: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bill)

        mobile = intent.getStringExtra("mobile").toString()
        buildingCode = intent.getStringExtra("code").toString()
        mykey=intent.getStringExtra("fcm").toString()

        back = findViewById(R.id.back)
        add = findViewById(R.id.add)
        recyclerview = findViewById(R.id.recyler)
        progress = findViewById(R.id.progressBar)

        // Fetching data from Firebase
        fetchData()

        // Initialize RecyclerView and Adapter
        recyclerview.layoutManager = LinearLayoutManager(this)
        billAdapter = BillAdapter(ArrayList())
        recyclerview.adapter = billAdapter

        // Back button click listener
        back.setOnClickListener {
            finish()
        }

        // Add button click listener
        add.setOnClickListener {
            openDialogData()
        }
    }

    // Fetch bills data from Firebase
    private fun fetchData() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("Bills")

        billsReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val billsList = ArrayList<BillData>()
                for (blockSnapshot in snapshot.children) {
                    val blockName = blockSnapshot.key
                    for (billSnapshot in blockSnapshot.children) {
                        val key = billSnapshot.key
                        val bill = billSnapshot.getValue(BillData::class.java)
                        bill?.let {
                            val billWithBlock = it.copy(block = blockName ?: "", key = key ?: "")
                            billsList.add(billWithBlock)
                        }
                    }
                }
                billAdapter.add(billsList)
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
               // Toast.makeText(this@Bills, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }

    // Dialog to add new bill
    private fun openDialogData() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.newbill)
        val billTitle = dialog.findViewById<EditText>(R.id.billtitle)
        val billDescription = dialog.findViewById<EditText>(R.id.billdescription)
        val deadline = dialog.findViewById<TextView>(R.id.deadlinedate)
        val billBlock = dialog.findViewById<EditText>(R.id.blocknm)
        val saveButton = dialog.findViewById<Button>(R.id.save)
        val price = dialog.findViewById<EditText>(R.id.price)
        val progressBar = dialog.findViewById<ProgressBar>(R.id.progressBarBill)

        deadline.setOnClickListener {
            showDatePickerDialog(deadline)
        }

        saveButton.setOnClickListener {
            val title = billTitle.text.toString()
            val descp = billDescription.text.toString()
            val dd = deadline.text.toString()
            val pr = price.text.toString()
            val blck = billBlock.text.toString()
            block=blck
            val cd=getCurrentDate()

            if (title.isNotEmpty() && descp.isNotEmpty() && dd.isNotEmpty() && pr.isNotEmpty() && blck.isNotEmpty()) {
                progressBar.visibility = View.VISIBLE

                // Saving new bill data to Firebase
                saveBillToFirebase(title, descp, dd, pr, blck, cd, progressBar, dialog)
            } else {
              //  Toast.makeText(this@Bills, "Please fill in all fields!", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }



    // Show date picker dialog
    private fun showDatePickerDialog(deadlineEditText: TextView) {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(selectedYear, selectedMonth, selectedDay)

                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val formattedDate = dateFormat.format(selectedDate.time)

                deadlineEditText.setText(formattedDate)
            },
            year,
            month,
            day
        )

        // Set minimum date to current date
        datePickerDialog.datePicker.minDate = currentDate.timeInMillis

        datePickerDialog.show()

        // Access the buttons of the DatePickerDialog and set their text color
        val positiveButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_POSITIVE)
        positiveButton.setTextColor(ContextCompat.getColor(this, R.color.black))

        val negativeButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_NEGATIVE)
        negativeButton.setTextColor(ContextCompat.getColor(this, R.color.black))
    }


    // Get current date
    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }

    // Save bill data to Firebase
    private fun saveBillToFirebase(title: String, descp: String, dd: String, pr: String, blck: String, cd: String, progressBar: ProgressBar, dialog: Dialog) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("Bills")
            .child("Block"+blck)
            .push()
        val key=reference.key.toString()
        val st="pending"

        val bill = BillData(key,title, descp, dd, blck, pr, cd, st, mobile,buildingCode)

        reference.setValue(bill)
            .addOnSuccessListener {
                //Toast.makeText(this@Bills, "Bill saved successfully!", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.GONE

                addDatatieachApartment(key, bill, blck)

                dialog.dismiss()
                fetchData()
            }
            .addOnFailureListener { e ->
               // Toast.makeText(this@Bills, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.GONE
            }
    }

    // Add bill data to each apartment
    private fun addDatatieachApartment(key: String, bill: BillData, blck: String) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("blocks")
            .child("Block"+blck)

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val uniqueNumbersList = mutableListOf<String>()
                dataSnapshot.children.forEach { child ->
                    val apartmentReference = child.ref.child("bills").child(key)
                    apartmentReference.setValue(bill)
                        .addOnSuccessListener {
                            // Handle success
                            // fetchData()
                        }
                        .addOnFailureListener { e ->
                            // Handle failure
                           // Toast.makeText(this@Bills, "Failed to add bill to apartment ${child.key}: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    uniqueNumbersList.add(child.key!!)
                }

                adduniquelist(key, blck)
            }

            override fun onCancelled(databaseError: DatabaseError) {
               // Toast.makeText(this@Bills, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Add unique list to Firebase for each bill
    private fun adduniquelist(key: String, blck: String) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("Bills")
            .child("Block"+blck)
            .child(key)
            .child("pending")

        val blockReference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("blocks")
            .child("Block"+blck)

        blockReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                dataSnapshot.children.forEach { child ->
                    reference.child(child.key!!).setValue(true)
                        .addOnSuccessListener {
                            // Handle success

                            //sendRealtimeNotification(mykey,"dmXUalmbRDS5l8fWK3NeeU:APA91bE6YjQj8XLUFEoTi7DqIrjVTCgCYd8jdSsuVKcxvKGRdyscjGneKH8tdGcYK7KIeyv5YWC_6w7ajodPFXK0FZW3JwunIPLCaLVQ3bd8MdvwOZ797zsqlNREjUwpcM1t97qzUnGb")
                        }
                        .addOnFailureListener { e ->
                            //Toast.makeText(this@Bills, "Error adding number ${child.key}: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                fetchDataFromRealtimeDatabase("Block"+blck)
            }

            override fun onCancelled(databaseError: DatabaseError) {
               // Toast.makeText(this@Bills, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun sendRealtimeNotification(mykey: String, donorkey: String) {
        val token: String = mykey

        if (token.isNotEmpty()) {
            val jsonObject = JSONObject()
            val notification = JSONObject()
            notification.put("body", "Hey!! You Have A New Bill")
            notification.put("title", "Dwell")

            jsonObject.put("to", donorkey)
            jsonObject.put("notification", notification)

            callApi(jsonObject)
        } else {
            //showToast("FCM token is empty")
        }
    }
    private fun fetchDataFromRealtimeDatabase(block:String) {
        val userReference = FirebaseDatabase.getInstance().getReference("Users").child(mobile).child("Buildings").child(buildingCode).child("BillFCM").child(block)



        userReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { dataSnapshot ->
                    val number = dataSnapshot.key
                    val key=dataSnapshot.value.toString()
                   // Toast.makeText(this@Bills,number.toString(),Toast.LENGTH_SHORT).show()

                    sendRealtimeNotification(mykey,key)


                }
                //sendNotification(mutableList)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }


    private fun callApi(jsonObject: JSONObject) {
        val JSON: MediaType = "application/json".toMediaType()
        val client = OkHttpClient()
        val url = "https://fcm.googleapis.com/fcm/send"
        val body = RequestBody.create(JSON, jsonObject.toString())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header(
                "Authorization",
                "Bearer AAAAp_fHqIc:APA91bHxvQvMBi_wRiDQy5wFNTEarvg8Ul_BIcNqoxKDHfrvN1zTmZ1kcyiQ_CdwzXCiqE5fTmii88EpWQu29avoEq72c7axe8n12GlPPQhb0k0E-mKKO0WqhfyXlvNCpV520Zgv2Csh"
            ) // Replace YOUR_SERVER_KEY with your Firebase Cloud Messaging server key
            .build()

        // Show progress bar when starting the network request

        progress.visibility = View.VISIBLE


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Hide progress bar when request completes (either success or failure)

                progress.visibility = View.GONE
               // showToast("Failed to send notification: ${e.message}")

            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    // Hide progress bar when request completes (either success or failure)
                    runOnUiThread {
                        progress.visibility = View.GONE
                       // showToast("Failed to send notification: ${response.code}")
                    }
                } else {
                    // Hide progress bar when request completes successfully
                    runOnUiThread {
                        saveNotificationData()
                        progress.visibility = View.GONE
                       // showToast("Notification Sent Successfully")
                    }
                }
            }

        })
    }

    private fun showToast(message: String) {
        runOnUiThread {
            //Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }
    private fun saveNotificationData() {
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("Notifications")
            .child("Users")
            .push()


        progress.visibility = ProgressBar.VISIBLE
        // this is the function to save the notification data

        val interactionData = HashMap<String, Any>()
        interactionData["type"]="bill"
        interactionData["block"]=block
        interactionData["heading"] = "You have new bill . Please pay the bill in time"
        interactionData["time"] =getCurrentDate()
        interactionData["date"] = getCurrentTime()

        interactionRef.setValue(interactionData)
            .addOnSuccessListener {
                NotifyBlink()
                progress.visibility = ProgressBar.GONE
              //  Toast.makeText(this, "Notification Saved Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Failed  to save  Notification   ", Toast.LENGTH_SHORT).show()
            }
    }
    private fun getCurrentTime(): String {
        val currentTime = Calendar.getInstance()
        val hour = currentTime.get(Calendar.HOUR_OF_DAY)
        val minute = currentTime.get(Calendar.MINUTE)
        val second = currentTime.get(Calendar.SECOND)
        return "$hour:$minute:$second"
    }
    private fun NotifyBlink(){
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(mobile)
            .child("Buildings")
            .child(buildingCode)
            .child("Notifications")
            .child("Users")
            .child("blink").setValue(getCurrentDate()+"/"+getCurrentTime())

        progress.visibility = ProgressBar.VISIBLE


        interactionRef
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
               // Toast.makeText(this, "Notification Blinked Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Failed  to Blink  Notification   ", Toast.LENGTH_SHORT).show()
            }

    }
}